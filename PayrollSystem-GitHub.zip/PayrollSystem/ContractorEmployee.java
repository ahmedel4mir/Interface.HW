public class ContractorEmployee extends Employee {
    private double hourlyRate;
    private int hoursWorked;

    public ContractorEmployee(String id, String name, String joinDate, double hourlyRate, int hoursWorked) {
        super(id, name, joinDate, 0);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double calculateNetSalary() {
        return hourlyRate * hoursWorked;
    }

    @Override
    public double calculateTax() {
        return calculateNetSalary() * TAX_RATE;
    }

    @Override
    public double calculateBonus(double score) {
        if (score > 4.0) {
            return 500.0;
        }
        return 0.0;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }
}
