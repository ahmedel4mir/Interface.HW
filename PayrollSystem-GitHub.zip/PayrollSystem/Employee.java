public abstract class Employee implements Taxable, BonusCalculable, Comparable<Employee> {
    protected String id;
    protected String name;
    protected String joinDate;
    protected double baseSalary;

    public Employee(String id, String name, String joinDate, double baseSalary) {
        this.id = id;
        this.name = name;
        this.joinDate = joinDate;
        this.baseSalary = baseSalary;
    }

    public abstract double calculateNetSalary();

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getJoinDate() {
        return joinDate;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    @Override
    public int compareTo(Employee other) {
        return Double.compare(other.calculateNetSalary(), this.calculateNetSalary());
    }
}
