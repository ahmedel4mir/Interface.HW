public class FullTimeEmployee extends Employee {
    private double allowance;

    public FullTimeEmployee(String id, String name, String joinDate, double baseSalary, double allowance) {
        super(id, name, joinDate, baseSalary);
        this.allowance = allowance;
    }

    @Override
    public double calculateNetSalary() {
        return baseSalary + allowance;
    }

    @Override
    public double calculateTax() {
        return calculateNetSalary() * TAX_RATE;
    }

    @Override
    public double calculateBonus(double score) {
        return baseSalary * 0.10 * (score / 5.0);
    }

    public double getAllowance() {
        return allowance;
    }
}
