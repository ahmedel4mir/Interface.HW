# Payroll Management System

A Java application implementing basic OOP concepts, polymorphism, interfaces, and collection sorting.

## Requirements
- Java JDK 11+

## Project Structure
- `Taxable.java`: Interface for tax calculations.
- `BonusCalculable.java`: Interface for performance bonus calculations.
- `Employee.java`: Abstract base class implementing interfaces and `Comparable`.
- `FullTimeEmployee.java`: Subclass for full-time staff.
- `ContractorEmployee.java`: Subclass for contract staff.
- `PayrollSystem.java`: Main entry point demonstrating features.
