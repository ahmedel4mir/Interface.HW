import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PayrollSystem {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new FullTimeEmployee("E001", "Ahmed Mohamed", "2020-05-15", 5000.0, 1200.0));
        employees.add(new FullTimeEmployee("E002", "Sara Ali", "2018-11-10", 7000.0, 1500.0));
        employees.add(new ContractorEmployee("C001", "Khaled Abdullah", "2022-01-20", 50.0, 160));
        employees.add(new ContractorEmployee("C002", "Mona Hassan", "2021-03-05", 40.0, 140));

        Collections.sort(employees);
        employees.sort(Comparator.comparing(Employee::getJoinDate));

        double totalTax = 0;
        double totalBonus = 0;
        double sampleScore = 4.6;

        for (Employee emp : employees) {
            totalTax += emp.calculateTax();
            totalBonus += emp.calculateBonus(sampleScore);
        }
    }
}
